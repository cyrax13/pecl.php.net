--TEST--
AMQPQueue::get headers
--SKIPIF--
<?php
if (!extension_loaded("amqp")) print "skip AMQP extension is not loaded";
elseif (!getenv("PHP_AMQP_HOST")) print "skip PHP_AMQP_HOST environment variable is not set";
?>
--FILE--
<?php
$cnn = new AMQPConnection();
$cnn->setHost(getenv('PHP_AMQP_HOST'));
$cnn->connect();

$ch = new AMQPChannel($cnn);

$ex = new AMQPExchange($ch);
$ex->setName('exchange' . bin2hex(random_bytes(32)));
$ex->setType(AMQP_EX_TYPE_TOPIC);
$ex->declareExchange();
$q = new AMQPQueue($ch);
$q->setName('queue1' . bin2hex(random_bytes(32)));
$q->declareQueue();
$q->bind($ex->getName(), '#');


// publish a message:
$ex->publish(
    'body', 'routing.1', AMQP_NOPARAM, array(
        'headers' => array(
            'foo' => 'bar',
            'baz' => array('a', 'bc', 'def')
        )
    )
);

// Read from the queue
$msg = $q->get(AMQP_AUTOACK);

$headers = $msg->getHeaders();
ksort($headers);

var_dump($headers);
echo $msg->getHeader('foo') . "\n";
var_dump($msg->getHeader('baz'));

$ex->delete();
$q->delete();
?>
--EXPECT--
array(2) {
  ["baz"]=>
  array(3) {
    [0]=>
    string(1) "a"
    [1]=>
    string(2) "bc"
    [2]=>
    string(3) "def"
  }
  ["foo"]=>
  string(3) "bar"
}
bar
array(3) {
  [0]=>
  string(1) "a"
  [1]=>
  string(2) "bc"
  [2]=>
  string(3) "def"
}
