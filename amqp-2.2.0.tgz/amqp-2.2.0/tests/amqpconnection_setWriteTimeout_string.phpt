--TEST--
AMQPConnection setWriteTimeout string
--SKIPIF--
<?php
if (!extension_loaded("amqp")) print "skip AMQP extension is not loaded";
elseif (!getenv("PHP_AMQP_HOST")) print "skip PHP_AMQP_HOST environment variable is not set";
?>
--FILE--
<?php
$cnn = new AMQPConnection();
$cnn->setHost(getenv('PHP_AMQP_HOST'));
$cnn->setWriteTimeout(".34");
var_dump($cnn->getWriteTimeout());
$cnn->setWriteTimeout("4.7e-2");
var_dump($cnn->getWriteTimeout());
?>
--EXPECT--
float(0.34)
float(0.047)
